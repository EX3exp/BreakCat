# 🐱 BreakCat - 뷁캣 🐱
> ### UTAU 음원들을 위한 뷁어변환기 
> #### - The Mojibake Maker For UTAU Voicebanks <br>
**UTAU 음원**이 가지고 있는 `파일명`, `oto.ini`의 **인코딩**을 바꿔 줘요.<br>
<br>⚠️ 의도적인 **글자 깨짐**을 유도하는 프로그램으로, 잘못 사용할 시 되돌릴 수 없답니다.😱 
<br> 꼭 필요한 경우에만 주의해서 사용해 주세요!
&nbsp;<br>

<img src=https://github.com/EX3exp/BreakCat/assets/100339835/3d69d332-14de-4980-87e9-fd09ba559ade width=500px></img>
<img src=https://github.com/EX3exp/BreakCat/assets/100339835/1da11063-674a-45eb-91da-d15d7e5a98e5 width=500px></img>
<img src=https://github.com/EX3exp/BreakCat/assets/100339835/67a56bfe-2122-44a0-af32-2d289c8dd093 width=500px></img>
<img src=https://github.com/EX3exp/BreakCat/assets/100339835/3ba50ac7-259e-49e5-89cb-ce1747ea834b width=500px></img>

<br>


# 🐱 Download - 다운로드 🐱
> 하단의 링크를 누르면 Release로 이동해요.<br>
> [🐈 ➡️ Go to Release](https://github.com/EX3exp/BreakCat/releases/latest)
